import re
from typing import Dict, List

def extract_paragraphs_by_topic(text, topics):
    """
    Processes text line by line and maps each topic to a list of dictionaries
    containing the line number and corresponding paragraph.
    """
    topic_dict = {topic: [] for topic in topics}

    lines = text.split("\n")  # Split text by lines to track line numbers
    
    # Track paragraph boundaries more precisely
    current_paragraph_lines = []
    paragraph_start_line = None
    
    for line_number, line in enumerate(lines, start=1):
        if line.strip():
            if paragraph_start_line is None:
                paragraph_start_line = line_number
            current_paragraph_lines.append(line.strip())
        else:
            if current_paragraph_lines:
                paragraph_text = " ".join(current_paragraph_lines)
                for topic in topics:
                    if topic.lower() in paragraph_text.lower():
                        # Store the actual text with original line breaks for verification
                        topic_dict[topic].append({
                            "line_number": paragraph_start_line,
                            "text": paragraph_text,
                        })
                current_paragraph_lines = []
                paragraph_start_line = None

    # Handle last paragraph if text didn't end with a blank line
    if current_paragraph_lines:
        paragraph_text = " ".join(current_paragraph_lines)
        for topic in topics:
            if topic.lower() in paragraph_text.lower():
                topic_dict[topic].append({
                    "line_number": paragraph_start_line,
                    "text": paragraph_text
                })

    return topic_dict